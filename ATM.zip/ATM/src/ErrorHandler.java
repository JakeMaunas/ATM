public class ErrorHandler extends Exception{
    public ErrorHandler(String mess) {
        super(mess);
    }
}
