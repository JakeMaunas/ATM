public class Main {
    public static void main(String[] args) {
        Atm_Machine ATM = new Atm_Machine();
    }
}